package com.training;

public abstract class Instrument
{
public abstract void Play();
}